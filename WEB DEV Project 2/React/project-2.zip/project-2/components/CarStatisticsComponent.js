import { useState, useEffect } from 'react';
import { isWithinInterval, parseISO, startOfDay, endOfDay } from 'date-fns';

const CarStatisticsComponent = () => {
  const [totalCars, setTotalCars] = useState(0);
  const [rentedCars, setRentedCars] = useState(0);
  const [carsDueMaintenance, setCarsDueMaintenance] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Concurrently fetch cars and rentals data
        const [carsRes, rentalsRes] = await Promise.all([
          fetch('/api/cars'),
          fetch('/api/rentals')
        ]);

        if (!carsRes.ok || !rentalsRes.ok) {
          throw new Error('Network response was not okay');
        }

        const [carsData, rentalsData] = await Promise.all([
          carsRes.json(),
          rentalsRes.json()
        ]);

        const cars = carsData.data || [];
        const rentals = rentalsData.data || [];

        setTotalCars(cars.length);

        // Calculate rented out cars
        const today = new Date();
        const rentedOutCars = rentals.filter(rental => isWithinInterval(today, {
          start: parseISO(rental.Rental_Start),
          end: parseISO(rental.Rental_End)
        })).length;
        setRentedCars(rentedOutCars);

        // Calculate cars due for maintenance
        const maintenanceThreshold = 15000;
        const maintenanceAlertRange = 5000;
        const dueMaintenanceCars = cars.filter(car => {
          const mileage = parseInt(car.Mileage.replace(/,/g, ''), 10);
          const kilometersToNextMaintenance = maintenanceThreshold - (mileage % maintenanceThreshold);
          return kilometersToNextMaintenance <= maintenanceAlertRange;
        }).length;
        setCarsDueMaintenance(dueMaintenanceCars);

      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="bg-black shadow-lg rounded-lg p-4">
      <h2 className="text-xl font-semibold text-white mb-2">Car Statistics</h2>
      <p className="text-white mb-1">RENTED OUT CARS: {rentedCars} / {totalCars}</p>
      <p className="text-white">CARS DUE MAINTENANCE: {carsDueMaintenance} / {totalCars}</p>   
    </div>
  );
};

export default CarStatisticsComponent;
