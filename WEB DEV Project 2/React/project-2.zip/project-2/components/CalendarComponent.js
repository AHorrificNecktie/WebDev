import { useState, useEffect } from 'react';
import { format, addDays, startOfWeek, parseISO, isWithinInterval } from 'date-fns';

const CalendarCell = ({ isRented, onClick }) => {
  const cellStyle = isRented ? 'bg-red-500 hover:bg-red-700' : 'bg-green-500 hover:bg-green-700';
  const textStyle = 'text-white font-bold';

  return (
    <div
      className={`p-2 ${cellStyle} ${textStyle} rounded m-1 shadow cursor-pointer transition duration-300 ease-in-out`}
      onClick={onClick}
    >
    </div>
  );
};

const CalendarGrid = ({ onSelectRental }) => {
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRentals = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/rentals');
        if (!response.ok) {
          throw new Error('Network response was not okay');
        }
        const result = await response.json();
        if (result.success && Array.isArray(result.data)) {
          setRentals(result.data);
        } else {
          throw new Error('Data is not an array');
        }
      } catch (error) {
        console.error(error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchRentals();
  }, []);

  const getNext7Days = () => {
    const today = startOfWeek(new Date(), { weekStartsOn: 1 });
    return Array.from({ length: 7 }, (_, i) => addDays(today, i));
  };

  const days = getNext7Days();

  const isRentedOnDate = (rental, date) => {
    return isWithinInterval(date, {
      start: parseISO(rental.Rental_Start),
      end: parseISO(rental.Rental_End),
    });
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="container mx-auto my-8 p-4 bg-black rounded-lg shadow-xl">
      <h2 className="text-3xl font-semibold mb-6 text-center text-white">Rental Calendar</h2>
      <div className="grid grid-cols-8 text-center font-bold">
        <div className="col-span-1 p-2 border bg-black rounded">Car Details</div>
        {days.map((date, index) => (
          <div key={index} className="col-span-1 p-2 border bg-black rounded">
            {format(date, 'EEE dd/MM')}
          </div>
        ))}
      </div>
      {rentals.map((rental, carIndex) => (
        <div key={rental._id} className="grid grid-cols-8">
          <div
            className="col-span-1 p-2 border cursor-pointer hover:bg-slate-800 rounded"
            onClick={() => onSelectRental(rental)}
          >
            {rental.Name} - {rental.Category} - {rental.Automatic ? 'Auto' : 'Manual'}
          </div>
          {days.map((date, dateIndex) => (
            <CalendarCell
              key={`${carIndex}-${dateIndex}`}
              isRented={isRentedOnDate(rental, date)}
              onClick={() => onSelectRental(rental)}
            />
          ))}
        </div>
      ))}
    </div>
  );
};

export default CalendarGrid;
