import { useState, useEffect } from 'react';
import { format, addDays, startOfWeek, parseISO, isWithinInterval } from 'date-fns';

const ShortenedCalendarComponent = () => {
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRentals = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/rentals');
        if (!response.ok) {
          throw new Error('Network response was not okay');
        }
        const result = await response.json();
        if (result.success && Array.isArray(result.data)) {
          setRentals(result.data);
        } else {
          throw new Error('Data is not an array');
        }
      } catch (error) {
        console.error(error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchRentals();
  }, []);

  // Helper function to check if a car is rented on a particular date
  const isCarRentedOnDate = (rental, date) => {
    return isWithinInterval(date, {
      start: parseISO(rental.Rental_Start),
      end: parseISO(rental.Rental_End),
    });
  };

  // Get today's date and the next 6 days for a week overview
  const today = new Date();
  const next7Days = Array.from({ length: 7 }, (_, i) => addDays(today, i));

  // Filter rentals to only include those happening within the next 7 days
  const upcomingRentals = rentals.filter(rental =>
    next7Days.some(date => isCarRentedOnDate(rental, date))
  );

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="flex flex-row">
    <div className="bg-black shadow-lg rounded-lg p-4">
      <h2 className="text-xl font-semibold text-white mb-2">Upcoming Rentals</h2>
      {upcomingRentals.slice(0, 5).map((rental, index) => (
        <div key={index} className="text-white mb-1">
          <strong>{format(parseISO(rental.Rental_Start), 'EEE dd/MM')}</strong>: {rental.Name} - {rental.Registration}
        </div>
      ))}
    </div>
    <div className="bg-black shadow-lg rounded-lg p-4">
    <h2 className="text-xl font-semibold text-white mb-2">Rentals Due:</h2>
      {upcomingRentals.slice(0, 5).map((rental, index) => (
        <div key={index} className="text-white mb-1">
          <strong>{format(parseISO(rental.Rental_End), 'EEE dd/MM')}</strong>: {rental.Name} - {rental.Registration}
        </div>
      ))}
    </div>
    </div>
  );
};

export default ShortenedCalendarComponent;
