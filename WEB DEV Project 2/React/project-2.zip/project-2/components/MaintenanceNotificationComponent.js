import { useState, useEffect } from 'react';

const MaintenanceNotificationComponent = () => {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCars = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/cars');
        if (!response.ok) {
          throw new Error(`Network response was not okay: ${response.statusText}`);
        }
        const result = await response.json();
        setCars(result.data || []);
      } catch (error) {
        console.error('Failed to fetch cars:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCars();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  const maintenanceThreshold = 15000;
  const maintenanceAlertRange = 5000;

  const carsCloseToMaintenance = cars.filter(car => {
    // Ensure we convert the string mileage to a number before the calculation
    const mileage = parseInt(car.Mileage.replace(/,/g, ''), 10);
    const kilometersToNextMaintenance = maintenanceThreshold - (mileage % maintenanceThreshold);
    return kilometersToNextMaintenance <= maintenanceAlertRange;
  });

  return (
    <div className="bg-black shadow-lg rounded-lg p-4">
      <h2 className="text-xl font-semibold text-white mb-2">Maintenance Notifications</h2>
      {carsCloseToMaintenance.length > 0 ? (
        carsCloseToMaintenance.map((car) => (
          <div key={car.Registration} className="text-white mb-1">
            <strong> {car.Name} - {car.Registration}</strong>: {maintenanceThreshold - (parseInt(car.Mileage.replace(/,/g, ''), 10) % maintenanceThreshold)} km to maintenance
          </div>
        ))
      ) : (
        <p className="text-white">No maintenance alerts.</p>
      )}
    </div>
  );
};

export default MaintenanceNotificationComponent;
