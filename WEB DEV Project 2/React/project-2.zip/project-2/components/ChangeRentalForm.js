import React, { useState } from 'react';
import Link from 'next/link';

const RentalEditForm = ({ rentalId, currentStart, currentEnd }) => {
  const [start, setStart] = useState(currentStart);
  const [end, setEnd] = useState(currentEnd);
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await updateRentalDates(rentalId, start, end);
    } catch (error) {
      setError(error.message);
    }
  };

  const updateRentalDates = async (rentalId, start, end) => {
    try {
      const response = await fetch(`/api/rentals/${rentalId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          Rental_Start: start,
          Rental_End: end,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Could not update rental');
      } 
    } catch (error) {
      console.error('Failed to update rental:', error);
    }
  };  

 return (
    <div className="max-w-md mx-auto bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="mb-4">
          <label htmlFor="start" className="block text-gray-700 text-sm font-bold mb-2">
            Rental Start Date:
          </label>
          <input
            type="date"
            id="start"
            value={start}
            onChange={(e) => setStart(e.target.value)}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          />
        </div>
        <div className="mb-6">
          <label htmlFor="end" className="block text-gray-700 text-sm font-bold mb-2">
            Rental End Date:
          </label>
          <input
            type="date"
            id="end"
            value={end}
            onChange={(e) => setEnd(e.target.value)}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          />
        </div>
        <div className="flex items-center justify-between">
          <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
            Update Rental Dates
          </button>
          <Link href={`/cars/${rentalId}`} passHref>
            <button className="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
              View Car Details
            </button>
          </Link>
        </div>
        {error && <p className="text-red-500 text-xs italic">{error}</p>}
      </form>
    </div>
  );
};

export default RentalEditForm;