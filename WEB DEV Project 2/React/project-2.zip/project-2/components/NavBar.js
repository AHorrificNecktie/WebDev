import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

const NavBar = () => {
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem('token');
    router.push('/'); 
  };

  return (
    <nav className="flex flex-col space-y-4 bg-black p-4 text-white h-screen">
      <Link href="/dashboard">
        <span className="text-gray-300 hover:bg-gray-700 p-2 rounded cursor-pointer">Dashboard</span>
      </Link>
      <Link href="/calendar">
        <span className="text-gray-300 hover:bg-gray-700 p-2 rounded cursor-pointer">Calendar</span>
      </Link>
      <Link href="/cars">
        <span className="text-gray-300 hover:bg-gray-700 p-2 rounded cursor-pointer">Cars</span>
      </Link>
      <Link href="/rent">
        <span className="text-gray-300 hover:bg-gray-700 p-2 rounded cursor-pointer">Rent</span>
      </Link>
      <button onClick={handleLogout} className="text-gray-300 hover:bg-gray-700 p-2 rounded cursor-pointer">
        Logout
      </button>
    </nav>
  );
};

export default NavBar;

  