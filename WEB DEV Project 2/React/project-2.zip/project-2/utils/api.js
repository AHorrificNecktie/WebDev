export const fetchProtectedData = async () => {
    const token = localStorage.getItem('token');
    
    const response = await fetch('http://localhost:3001/api/protected', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
  
    if (!response.ok) {
      throw new Error('Unable to fetch protected data. Please log in again.');
    }
  
    return await response.json();
  };
  