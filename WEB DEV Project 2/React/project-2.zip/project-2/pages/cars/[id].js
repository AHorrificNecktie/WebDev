import React, { useState } from 'react';
import { useRouter } from 'next/router';
import NavBar from '../../components/NavBar';

export default function CarDetails({ car }) {
  const router = useRouter();
  const { id } = router.query;
  const [editMode, setEditMode] = useState(false);
  const [updatedCar, setUpdatedCar] = useState(car);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdatedCar({ ...updatedCar, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/cars/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedCar),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update car details');
      alert('Car details updated successfully');
      setEditMode(false); // Exit edit mode
    } catch (error) {
      console.error('Failed to update car details:', error);
      alert(error.message);
    }
  };

  if (!car) {
    return <p>Loading...</p>;
  }

  return (
    <div className="flex min-h-screen bg-slate-800">
      <NavBar />
      <div className="flex-1 flex flex-col items-center">
        <div className="w-full max-w-4xl p-6">
          <button onClick={() => router.back()} className="mb-5 bg-slate-800 text-white px-3 py-2 rounded hover:bg-black transition duration-300">
            Back
          </button>
          {editMode ? (
            <form onSubmit={handleSubmit} className="bg-black rounded-lg shadow overflow-hidden p-6 space-y-4">
              <h1 className="text-3xl font-bold text-white">Edit Car Details</h1>
              {/* Name field */}
              <label htmlFor="Name">Name:</label>
              <input
                type="text"
                id="Name"
                name="Name"
                value={updatedCar.Name}
                onChange={handleInputChange}
                className="mb-4 p-2 border rounded bg-black"
              />
              {/* SIPP Code field */}
              <label htmlFor="SIPP_Code">SIPP Code:</label>
              <input
                type="text"
                id="SIPP_Code"
                name="SIPP_Code"
                value={updatedCar.SIPP_Code}
                onChange={handleInputChange}
                className="mb-4 p-2 border rounded bg-black"
              />
              {/* Category field */}
              <label htmlFor="Category">Category:</label>
              <input
                type="text"
                id="Category"
                name="Category"
                value={updatedCar.Category}
                onChange={handleInputChange}
                className="mb-4 p-2 border rounded bg-black"
              />
              {/* Automatic field */}
              <label htmlFor="Automatic">Automatic:</label>
              <select
                id="Automatic"
                name="Automatic"
                value={updatedCar.Automatic}
                onChange={handleInputChange}
                className="mb-4 p-2 border rounded bg-black"
              >
                <option value="true">Yes</option>
                <option value="false">No</option>
              </select>
              {/* Registration field */}
              <label htmlFor="Registration">Registration:</label>
              <input
                type="text"
                id="Registration"
                name="Registration"
                value={updatedCar.Registration}
                onChange={handleInputChange}
                className="mb-4 p-2 border rounded bg-black"
              />

              {/* R_Expiry field */}
            <label htmlFor="R_Expiry">Registration Expiry:</label>
            <input
              type="text"
              id="R_Expiry"
              name="R_Expiry"
              value={updatedCar.R_Expiry}
              onChange={handleInputChange}
              className="mb-4 p-2 border rounded bg-black"
            />

            {/* Last_Service_KM field */}
            <label htmlFor="Last_Service_KM">Last Service KM:</label>
            <input
              type="text"
              id="Last_Service_KM"
              name="Last_Service_KM"
              value={updatedCar.Last_Service_KM}
              onChange={handleInputChange}
              className="mb-4 p-2 border rounded bg-black"
            />

            {/* Last_Service_Date field */}
            <label htmlFor="Last_Service_Date">Last Service Date:</label>
            <input
              type="text"
              id="Last_Service_Date"
              name="Last_Service_Date"
              value={updatedCar.Last_Service_Date}
              onChange={handleInputChange}
              className="mb-4 p-2 border rounded bg-black"
            />

            {/* Mileage field */}
            <label htmlFor="Mileage">Mileage:</label>
            <input
              type="text"
              id="Mileage"
              name="Mileage"
              value={updatedCar.Mileage}
              onChange={handleInputChange}
              className="mb-4 p-2 border rounded bg-black"
            />
            
              {/* ...other fields */}
              <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300">
              Save Changes
            </button>
          </form>
        ) : (
          <div className="bg-black shadow-lg rounded-lg overflow-hidden p-6 space-y-4">
            <h1 className="text-4xl font-bold text-white">{car.Name}</h1>
            {Object.entries(car).map(([key, value]) => (
              key !== '_id' && (
                <div key={key} className="text-lg text-white">
                  <span className="font-semibold capitalize">{key.replace(/_/g, ' ')}:</span> {value.toString()}
                </div>
              )
            ))}
            <button onClick={() => setEditMode(true)} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300">
              Edit
            </button>
          </div>
        )}
      </div>
    </div>
  </div>
);

}
// This gets called on every request
export async function getServerSideProps({ params }) {
  // Fetch data from external API
  const res = await fetch(`http://localhost:3000/api/cars/${params.id}`);
  const data = await res.json();

  // Pass data to the page via props
  return { props: { car: data.data || null } };
}
