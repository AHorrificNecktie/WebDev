// pages/cars/index.js
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import NavBar from '../../components/NavBar';

const CarsPage = () => {
  const [cars, setCars] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function getCars() {
      try {
        const response = await fetch('/api/cars');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.success) {
          setCars(data.data);
        } else {
          setError('Failed to load cars data');
        }
      } catch (e) {
        setError(e.message);
      }
    }

    getCars();
  }, []);

  return (
    <div className="flex h-screen bg-slate-800 overflow-hidden">
      <div className="flex-none" style={{ backgroundColor: '#000', width: '200px' }}>
        <NavBar />
      </div>
      <main className="flex-1 overflow-auto">
        <h1 className="text-3xl font-semibold mb-6">Cars</h1>
        {error && <p className="text-red-500">{error}</p>}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cars.map((car) => (
            <Link key={car._id} href={`/cars/${car._id}`}>
            <div className="block p-4 bg-slate-800 rounded-lg shadow-md hover:bg-black cursor-pointer">
              <h2 className="text-xl font-semibold text-white">{car.Name}</h2>
              <p className="text-white">{car.Registration}</p>
              <p className="text-white">{car.Category}</p>
            </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
};

export default CarsPage;