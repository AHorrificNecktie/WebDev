import NavBar from '../components/NavBar';
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import React, { useState } from 'react';
import ShortenedCalendarComponent from '../components/ShortenedCalendarComponent';
import MaintenanceNotificationComponent from '../components/MaintenanceNotificationComponent';
import CarStatisticsComponent from '../components/CarStatisticsComponent';

export default function Dashboard() {
  const router = useRouter();
  // State to manage whether the token check has been completed
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    // Perform a client-side check for the token
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/');
    } else {
      setIsChecking(false);
    }
  }, [router]);

  const username = 'Employee';

  if (isChecking) {
    return null;
  }

  return (
    <div className="flex h-screen bg-slate-800">
      <NavBar />
      <main className="flex-1 p-4">
        <header className="mb-4">
          <h1 className="text-2xl font-semibold text-white">Welcome, {username}</h1>
        </header>
        <section className="mb-6 bg-black shadow-lg rounded-lg p-6">
          <h2 className="font-semibold text-xl mb-4">Calendar Overview</h2>
          <ShortenedCalendarComponent />
        </section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <section className="mb-6 bg-black shadow-lg rounded-lg p-6">
            <h2 className="font-semibold">Important Notifications</h2>
            <MaintenanceNotificationComponent />
          </section>
          <section className="mb-6 bg-black shadow-lg rounded-lg p-6">
            <h2 className="font-semibold">Car Statistics</h2>
            <CarStatisticsComponent />
          </section>
        </div>
      </main>
    </div>
  );
}