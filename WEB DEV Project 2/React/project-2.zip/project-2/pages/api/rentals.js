import dbConnect from '../../../backend/utils/dbConnect';
import Rental from '../../../backend/models/Rental';

export default async function handler(req, res) {
  await dbConnect();

  if (req.method === 'GET') {
    try {
      const rentals = await Rental.find({}); // Fetch all rentals from the database
      console.log(rentals);
      res.status(200).json({ success: true, data: rentals });
    } catch (error) {
      res.status(400).json({ success: false, error: error.message });
    }
  } else {
    // If we hit this API route with a method other than GET
    res.setHeader('Allow', ['GET']);
    res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
  }
}
