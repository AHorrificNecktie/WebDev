// This is pseudo-code for the api/rentals/[id].js file

import dbConnect from '../../../../backend/utils/dbConnect';
import Rental from '../../../../backend/models/Rental';

export default async function handler(req, res) {
  const {
    query: { id },
    method,
  } = req;

  await dbConnect();

  switch (method) {
    case 'GET':
      break;
    case 'PUT':
      try {
        const rentalData = {
          Rental_Start: req.body.Rental_Start,
          Rental_End: req.body.Rental_End,
        };
        // Find the rental by ID and update it with the new dates
        const rental = await Rental.findByIdAndUpdate(id, rentalData, {
          new: true,
          runValidators: true,
        });
        if (!rental) {
          return res.status(404).json({ success: false, error: 'Rental not found' });
        }
        res.status(200).json({ success: true, data: rental });
      } catch (error) {
        res.status(400).json({ success: false, error: error.message });
      }
      break;
    default:
      res.setHeader('Allow', ['GET', 'PUT']);
      res.status(405).json({ success: false, error: `Method ${method} not allowed` });
  }
}
