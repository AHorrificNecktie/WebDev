
const dbConnect = require('../../../../backend/utils/dbConnect');
const Car = require('../../../../backend/models/Car');

export default async function handler(req, res) {
  try {
    await dbConnect();
    const cars = await Car.find({});
    console.log('Car data:', cars);
    res.status(200).json({ success: true, data: cars });
  } catch (error) {
    console.error('Error fetching cars:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}
