
import dbConnect from '../../../../backend/utils/dbConnect';
import Car from '../../../../backend/models/Car';

export default async function handler(req, res) {
  await dbConnect();

  const {
    query: { id },
    method,
  } = req;

  switch (method) {
    case 'GET':
      try {
        const car = await Car.findById(id);
        if (!car) {
          return res.status(404).json({ success: false, error: 'Car not found' });
        }
        res.status(200).json({ success: true, data: car });
      } catch (error) {
        res.status(400).json({ success: false, error: error.message });
      }
      break;

    case 'PUT':
      try {
        const car = await Car.findByIdAndUpdate(id, req.body, {
          new: true,
          runValidators: true,
        });
        if (!car) {
          return res.status(404).json({ success: false, error: 'Car not found' });
        }
        res.status(200).json({ success: true, data: car });
      } catch (error) {
        res.status(400).json({ success: false, error: error.message });
      }
      break;
    default:
      res.setHeader('Allow', ['GET', 'PUT']);
      res.status(405).json({ success: false, error: `Method ${method} not allowed` });
  }
}
