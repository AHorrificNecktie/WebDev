// pages/calendar.js
import React, { useState } from 'react';
import CalendarComponent from '../components/CalendarComponent';
import ChangeRentalForm from '../components/ChangeRentalForm';
import NavBar from '@/components/NavBar';

const CalendarPage = () => {
  const [selectedRental, setSelectedRental] = useState(null);

  const handleSelectRental = (rental) => {
    setSelectedRental(rental);
  };

  return (
    <div className="flex h-screen bg-black overflow-hidden">
      <div className="flex-none h-full" style={{ backgroundColor: '#000', width: '200px' }}>
        <NavBar />
      </div>
      <div className="flex-grow p-4 overflow-auto">
        {selectedRental ? (
          <ChangeRentalForm
            rentalId={selectedRental._id}
            currentStart={selectedRental.Rental_Start}
            currentEnd={selectedRental.Rental_End}
          />
        ) : (
          <CalendarComponent onSelectRental={handleSelectRental} />
        )}
      </div>
    </div>
  );
};

export default CalendarPage;
