import React, { useState, useEffect } from 'react';
import NavBar from '../components/NavBar';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

const RentPage = () => {
  const [cars, setCars] = useState([]);
  const [formData, setFormData] = useState({
    carId: '',
    arrival: '',
    departure: '',
    location: '',
    totalPrice: ''
  });

  useEffect(() => {
    // Fetch the list of cars from the database
    const fetchCars = async () => {
      const response = await fetch('/api/cars');
      const data = await response.json();
      setCars(data.data);
    };

    fetchCars();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };


  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const selectedCar = cars.find(car => car._id === formData.carId);
  if (!selectedCar) {
    alert('Please select a car.');
    return;
  }

  const carDetails = `${selectedCar.Name} - ${selectedCar.Registration}`;
  
    // Create a new PDF document
    const pdfDoc = await PDFDocument.create();
    
    // Embed font families
    const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
    const helveticaBoldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    
    // Add a page to the document
    const page = pdfDoc.addPage();
    const { width, height } = page.getSize();
    
    // Define a helper function to add text to the PDF
    const addText = (text, y, font = timesRomanFont, size = 12) => {
      page.drawText(text, {
        x: 50,
        y: height - y,
        size,
        font,
        color: rgb(0, 0, 0),
      });
    };
  
    // Title
    addText('Rental Contract', 50, helveticaBoldFont, 18);
  
    // Subtitle
    addText(`Contract for: ${carDetails}`, 80, helveticaBoldFont, 14);
  
    // Line to separate header from content
    page.drawLine({
      start: { x: 50, y: height - 100 },
      end: { x: width - 50, y: height - 100 },
      thickness: 1,
      color: rgb(0.65, 0.65, 0.65),
    });
  
    // Calculate the Y position for each new line
    let yOffset = 120;
    
    // Add form data to the PDF
    addText(`Car: ${carDetails}`, yOffset);
    yOffset += 20;
    addText(`Arrival: ${formData.arrival}`, yOffset);
    yOffset += 20;
    addText(`Departure: ${formData.departure}`, yOffset);
    yOffset += 20;
    addText(`Location: ${formData.location}`, yOffset);
    yOffset += 20;
    addText(`Total Price: ${formData.totalPrice} BAM`, yOffset);
    
    // Serialize the PDFDocument to bytes (a Uint8Array)
    const pdfBytes = await pdfDoc.save();
    
    // Trigger the download of the PDF
    downloadBlob(pdfBytes, 'rental-contract.pdf', 'application/pdf');
    
    alert('Contract generated and downloaded!');
  };
  
  // Utility function to trigger a download of a blob
  function downloadBlob(blob, filename, mimeType) {
    const blobUrl = URL.createObjectURL(new Blob([blob], { type: mimeType }));
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  return (
    <div className="flex min-h-screen bg-slate-800 text-white">
      <NavBar />
      <main className="flex-1 p-8">
        <h1 className="text-4xl font-semibold mb-10">Rent a Car</h1>
        <form onSubmit={handleFormSubmit} className="space-y-6 w-full max-w-4xl mx-auto bg-black text-white shadow-lg rounded-lg p-8">
          <div className="flex flex-col">
            <label htmlFor="carId" className="font-semibold mb-2">Select a Car:</label>
            <select
              name="carId"
              value={formData.carId}
              onChange={handleInputChange}
              required
              className="p-2 border rounded bg-black"
            >
              <option value="">Select a car</option>
              {cars.map(car => (
                <option key={car._id} value={car._id}>
                  {car.Name} - {car.Registration}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col">
            <label htmlFor="arrival" className="font-semibold mb-2">Arrival Date and Time:</label>
            <input
              type="datetime-local"
              name="arrival"
              value={formData.arrival}
              onChange={handleInputChange}
              required
              className="p-2 border rounded bg-black"
            />
          </div>

          <div className="flex flex-col">
            <label htmlFor="departure" className="font-semibold mb-2">Departure Date and Time:</label>
            <input
              type="datetime-local"
              name="departure"
              value={formData.departure}
              onChange={handleInputChange}
              required
              className="p-2 border rounded bg-black"
            />
          </div>

          <div className="flex flex-col">
            <label htmlFor="location" className="font-semibold mb-2">Location:</label>
            <select
              name="location"
              value={formData.location}
              onChange={handleInputChange}
              required
              className="p-2 border rounded bg-black"
            >
              <option value="">Select a location</option>
              <option value="bascarsija">Baščaršija Office</option>
              <option value="airport">Airport Office</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label htmlFor="totalPrice" className="font-semibold mb-2">Total Price (BAM):</label>
            <input
              type="number"
              name="totalPrice"
              value={formData.totalPrice}
              onChange={handleInputChange}
              required
              placeholder="Total Price (BAM)"
              className="p-2 border rounded bg-black"
            />
          </div>

          <button type="submit" className="w-full bg-blue-500 text-white py-3 rounded hover:bg-blue-600 transition duration-300">
            Generate Contract
          </button>
        </form>
      </main>
    </div>
  );
};

export default RentPage;
